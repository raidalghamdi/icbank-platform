var DES = (function() {

  // ── Upload progress overlay ─────────────────────────────────────
  function showOverlay(msg) {
    var existing = document.getElementById('des-upload-overlay');
    if (existing) { existing.querySelector('.des-upload-msg').textContent = msg || 'جاري الرفع…'; return; }
    var el = document.createElement('div');
    el.className = 'des-upload-overlay'; el.id = 'des-upload-overlay';
    el.innerHTML = '<div class="des-upload-box"><span class="des-upload-spinner">⏳</span><div class="des-upload-msg">' + (msg||'جاري الرفع…') + '</div></div>';
    document.body.appendChild(el);
  }
  function hideOverlay() {
    var el = document.getElementById('des-upload-overlay');
    if (el) el.remove();
  }

  // ── Init ────────────────────────────────────────────────────────
  function init() { loadLogos(); loadFonts(); }

  function switchTab(tab) {
    document.querySelectorAll('#des-tab-nav .adm-tab').forEach(function(b) { b.classList.remove('active'); });
    document.querySelectorAll('[id^="des-pane-"]').forEach(function(p) { p.classList.remove('active'); });
    var btn = document.querySelector('#des-tab-nav .adm-tab[data-tab="' + tab + '"]');
    if (btn) btn.classList.add('active');
    var pane = document.getElementById('des-pane-' + tab);
    if (pane) pane.classList.add('active');
    if (tab === 'templates') loadTemplates();
  }

  // ── Logos ───────────────────────────────────────────────────────
  function loadLogos() {
    var grid = document.getElementById('des-logos-grid');
    var loading = document.getElementById('des-logos-loading');
    if (!grid) return;
    loading.style.display = ''; grid.style.display = 'none'; loading.textContent = 'جاري التحميل…';
    apiFetch('/api/designs/logos').then(function(r) { return r.json(); }).then(function(logos) {
      loading.style.display = 'none'; grid.style.display = '';
      if (!logos.length) {
        grid.innerHTML = '<div class="des-loading">لا توجد شعارات مرفوعة بعد.</div>'; return;
      }
      grid.innerHTML = logos.map(function(logo) {
        var src = '/api/storage' + logo.fileUrl;
        var checker = logo.transparent
          ? 'background:repeating-conic-gradient(#ccc 0% 25%,#fff 0% 50%) 0 0/14px 14px'
          : 'background:var(--surface-2)';
        return '<div class="des-logo-card" data-id="' + logo.id + '">' +
          '<div class="des-logo-thumb" style="' + checker + '">' +
          '<img src="' + src + '" alt="' + (logo.logoName||'') + '" onerror="this.style.display=\'none\'">' +
          '</div>' +
          '<div class="des-logo-info">' +
          '<div class="des-logo-name">' + (logo.logoName||'—') + '</div>' +
          '<div class="des-logo-meta">' + (logo.transparent ? 'شفاف' : 'غير شفاف') + (logo.defaultWidth ? ' · ' + logo.defaultWidth + 'px' : '') + '</div>' +
          '</div>' +
          '<button class="btn btn-ghost" style="color:var(--danger);padding:6px;flex-shrink:0;" onclick="DES.deleteLogo(' + logo.id + ')" title="حذف">' +
          '<span class="ico"><svg><use href="#i-x"/></svg></span></button>' +
          '</div>';
      }).join('');
    }).catch(function() { loading.textContent = 'خطأ في تحميل الشعارات.'; loading.style.display = ''; grid.style.display = 'none'; });
  }

  function uploadLogo(input) {
    var file = input.files[0]; if (!file) return;
    if (file.type !== 'image/png') { alert('يُقبل PNG فقط للشعارات.'); input.value = ''; return; }
    var name = (document.getElementById('des-logo-name').value || '').trim() || file.name.replace(/\.[^.]+$/, '');
    var width = parseInt(document.getElementById('des-logo-width').value) || null;
    var transparent = document.getElementById('des-logo-transparent').checked;
    showOverlay('جاري رفع الشعار…');
    apiFetch('/api/designs/logos/upload-url', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileName: file.name, contentType: file.type })
    }).then(function(r) { return r.json(); }).then(function(data) {
      return fetch(data.uploadURL, { method: 'PUT', headers: { 'Content-Type': file.type }, body: file })
        .then(function(r) { if (!r.ok) throw new Error('فشل رفع الملف إلى التخزين'); return data.objectPath; });
    }).then(function(objectPath) {
      return apiFetch('/api/designs/logos', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ logoName: name, fileUrl: objectPath, transparent: transparent, defaultWidth: width })
      });
    }).then(function(r) { if (!r.ok) return r.json().then(function(e) { throw new Error(e.error||'خطأ'); }); })
    .then(function() {
      input.value = '';
      document.getElementById('des-logo-name').value = '';
      document.getElementById('des-logo-width').value = '';
      document.getElementById('des-logo-transparent').checked = false;
      loadLogos();
    }).catch(function(e) { alert('خطأ: ' + e.message); })
    .finally(function() { hideOverlay(); });
  }

  function deleteLogo(id) {
    if (!confirm('هل تريد حذف هذا الشعار؟')) return;
    apiFetch('/api/designs/logos/' + id, { method: 'DELETE' })
      .then(function() { loadLogos(); }).catch(function(e) { alert('خطأ: ' + e.message); });
  }

  // ── Fonts ───────────────────────────────────────────────────────
  function loadFonts() {
    var list = document.getElementById('des-fonts-list');
    var loading = document.getElementById('des-fonts-loading');
    if (!list) return;
    loading.style.display = ''; list.style.display = 'none'; loading.textContent = 'جاري التحميل…';
    apiFetch('/api/designs/fonts').then(function(r) { return r.json(); }).then(function(fonts) {
      loading.style.display = 'none'; list.style.display = '';
      if (!fonts.length) {
        list.innerHTML = '<div class="des-loading">لا توجد خطوط مرفوعة بعد.</div>'; return;
      }
      list.innerHTML = fonts.map(function(font) {
        return '<div class="des-font-row" data-id="' + font.id + '">' +
          '<div class="des-font-info">' +
          '<div class="des-font-name">' + (font.fontName||'—') + (font.isDefault ? ' <span style="font-size:10px;color:var(--primary);font-weight:700;margin-right:6px;">★ افتراضي</span>' : '') + '</div>' +
          '<div class="des-font-path">' + (font.fontFileUrl||'') + '</div>' +
          '</div>' +
          '<div class="des-font-actions">' +
          (font.isDefault ? '' : '<button class="btn btn-ghost des-btn-default" onclick="DES.setDefaultFont(' + font.id + ')">تعيين كافتراضي</button>') +
          '<button class="btn btn-ghost" style="color:var(--danger);padding:6px;" onclick="DES.deleteFont(' + font.id + ')" title="حذف">' +
          '<span class="ico"><svg><use href="#i-x"/></svg></span></button>' +
          '</div></div>';
      }).join('');
    }).catch(function() { loading.textContent = 'خطأ في تحميل الخطوط.'; loading.style.display = ''; list.style.display = 'none'; });
  }

  function uploadFont(input) {
    var file = input.files[0]; if (!file) return;
    var ext = file.name.split('.').pop().toLowerCase();
    if (ext !== 'woff2' && ext !== 'ttf') { alert('يُقبل woff2 وttf فقط.'); input.value = ''; return; }
    var name = (document.getElementById('des-font-name').value || '').trim() || file.name.replace(/\.[^.]+$/, '');
    var ct = ext === 'woff2' ? 'font/woff2' : 'font/ttf';
    showOverlay('جاري رفع الخط…');
    apiFetch('/api/designs/fonts/upload-url', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fileName: file.name, contentType: ct })
    }).then(function(r) { return r.json(); }).then(function(data) {
      return fetch(data.uploadURL, { method: 'PUT', headers: { 'Content-Type': ct }, body: file })
        .then(function(r) { if (!r.ok) throw new Error('فشل رفع الملف إلى التخزين'); return data.objectPath; });
    }).then(function(objectPath) {
      return apiFetch('/api/designs/fonts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fontName: name, fontFileUrl: objectPath, isDefault: false })
      });
    }).then(function(r) { if (!r.ok) return r.json().then(function(e) { throw new Error(e.error||'خطأ'); }); })
    .then(function() {
      input.value = ''; document.getElementById('des-font-name').value = '';
      loadFonts();
    }).catch(function(e) { alert('خطأ: ' + e.message); })
    .finally(function() { hideOverlay(); });
  }

  function setDefaultFont(id) {
    apiFetch('/api/designs/fonts/' + id + '/default', { method: 'PATCH' })
      .then(function() { loadFonts(); }).catch(function(e) { alert('خطأ: ' + e.message); });
  }

  function deleteFont(id) {
    if (!confirm('هل تريد حذف هذا الخط؟')) return;
    apiFetch('/api/designs/fonts/' + id, { method: 'DELETE' })
      .then(function() { loadFonts(); }).catch(function(e) { alert('خطأ: ' + e.message); });
  }

  // ── Templates ───────────────────────────────────────────────────
  var _templates = [];
  var _selectedTplId = null;

  function loadTemplates() {
    var loading = document.getElementById('des-tpl-loading');
    var wrap    = document.getElementById('des-tpl-wrap');
    var empty   = document.getElementById('des-tpl-empty');
    if (!loading) return;
    loading.style.display = ''; wrap.style.display = 'none'; empty.style.display = 'none';
    apiFetch('/api/designs/templates').then(function(r) { return r.json(); }).then(function(list) {
      _templates = list;
      loading.style.display = 'none';
      if (!list.length) { empty.style.display = ''; return; }
      wrap.style.display = '';
      var listEl = document.getElementById('des-tpl-list');
      listEl.innerHTML = list.map(function(t) {
        return '<div class="des-tpl-item" data-id="' + t.id + '" onclick="DES.selectTemplate(' + t.id + ')">' +
          '<div style="font-size:13px;">' + t.templateNameAr + '</div>' +
          '<div style="font-size:11px;color:var(--text-3);margin-top:2px;">' + t.category + ' · ' + t.canvasWidth + '×' + t.canvasHeight + '</div>' +
          '<button class="btn btn-primary" style="margin-top:8px;font-size:12px;padding:4px 12px;" onclick="event.stopPropagation();DES.edOpen(' + t.id + ')">فتح المحرّر</button>' +
          '</div>';
      }).join('');
      selectTemplate(list[0].id);
    }).catch(function() { loading.textContent = 'خطأ في تحميل القوالب.'; });
  }

  function selectTemplate(id) {
    _selectedTplId = id;
    document.querySelectorAll('#des-tpl-list .des-tpl-item').forEach(function(el) {
      el.classList.toggle('active', Number(el.dataset.id) === id);
    });
    var tpl = _templates.find(function(t) { return t.id === id; });
    if (tpl) renderCanvas(tpl);
  }

  // ── Canvas sizing helper ─────────────────────────────────────────
  // Sets outer container height and pct badge.
  // Layers are rendered at scaled coords directly — no CSS transform needed.
  function _sizeOuter(outer, scaledW, scaledH, zoomState, pctEl, scale) {
    if (zoomState === 'fit') {
      outer.style.height   = scaledH + 'px';
      outer.style.overflow = 'hidden';
    } else {
      var viewH = Math.round(window.innerHeight * 0.72);
      outer.style.height   = Math.min(scaledH, viewH) + 'px';
      outer.style.overflow = 'auto';
    }
    if (pctEl) pctEl.textContent = Math.round(scale * 100) + '%';
  }

  // Shorthand: scale a px value
  function _s(v, scale) { return Math.round(v * scale); }

  // ── Template zoom state ──────────────────────────────────────────
  var _tplZoom = 'fit';
  var _tplCurrentTpl = null;

  function tplZoom(action) {
    var outer = document.getElementById('des-canvas-outer');
    if (!outer || !_tplCurrentTpl) return;
    var W = _tplCurrentTpl.canvasWidth || 1920;
    var fitScale = outer.clientWidth / W;
    var cur = (_tplZoom === 'fit') ? fitScale : _tplZoom;
    if (action === 'fit') {
      _tplZoom = 'fit';
    } else if (action === '+') {
      _tplZoom = Math.min(cur * 1.25, 4);
    } else if (action === '-') {
      var next = cur * 0.8;
      _tplZoom = (next <= fitScale * 1.05) ? 'fit' : Math.max(next, 0.1);
    }
    renderCanvas(_tplCurrentTpl);
  }

  function renderCanvas(tpl) {
    _tplCurrentTpl = tpl;
    var outer  = document.getElementById('des-canvas-outer');
    var canvas = document.getElementById('des-canvas');
    if (!outer || !canvas) return;

    var W = tpl.canvasWidth  || 1920;
    var H = tpl.canvasHeight || 1080;
    var outerW = outer.clientWidth || outer.getBoundingClientRect().width;
    if (!outerW) { requestAnimationFrame(function() { renderCanvas(tpl); }); return; }

    var fitScale = outerW / W;
    var scale    = (_tplZoom === 'fit') ? fitScale : _tplZoom;
    var sw = _s(W, scale);
    var sh = _s(H, scale);

    // Size canvas element to scaled dimensions (no CSS transform used)
    canvas.style.width  = sw + 'px';
    canvas.style.height = sh + 'px';

    _sizeOuter(outer, sw, sh, _tplZoom, document.getElementById('des-tpl-zoom-pct'), scale);

    var html = '';

    // ── Layer 1: Background placeholder ────────────────────────
    html += '<div class="des-layer-bg" style="background:#7a8a9a;">' +
      '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:.25;">' +
      '<svg width="120" height="80" viewBox="0 0 120 80" fill="none">' +
      '<rect width="120" height="80" fill="#555"/>' +
      '<circle cx="40" cy="32" r="12" fill="#777"/>' +
      '<path d="M0 65 L35 40 L60 55 L85 30 L120 65Z" fill="#666"/>' +
      '</svg></div></div>';

    // ── Layer 2: Background panel (coords × scale) ──────────────
    var bp = tpl.backgroundPanelConfig;
    if (bp) {
      var r = parseInt(bp.color.slice(1,3),16);
      var g = parseInt(bp.color.slice(3,5),16);
      var b = parseInt(bp.color.slice(5,7),16);
      html += '<div class="des-layer-panel" style="' +
        'left:' + _s(bp.x,scale) + 'px;top:' + _s(bp.y,scale) + 'px;' +
        'width:' + _s(bp.width,scale) + 'px;height:' + _s(bp.height,scale) + 'px;' +
        'background:rgba(' + r + ',' + g + ',' + b + ',' + bp.opacity + ');"></div>';
    }

    // ── Layer 3: Text slots (coords × scale, font-size × scale) ─
    var TEST_TEXT = {
      title: 'العنوان الرئيسي للإعلان',
      body:  'هذا نص تجريبي يُعرض في مساحة النص الكامل لضمان صحة موضع الطبقة وحجم الخط والاتجاه.',
    };
    (tpl.textSlots || []).forEach(function(slot) {
      var textContent = TEST_TEXT[slot.key] || slot.label_ar || slot.key;
      html += '<div class="des-layer-text" style="' +
        'left:' + _s(slot.x,scale) + 'px;top:' + _s(slot.y,scale) + 'px;' +
        'width:' + _s(slot.width,scale) + 'px;height:' + _s(slot.height,scale) + 'px;' +
        'font-size:' + _s(slot.default_font_size,scale) + 'px;' +
        'color:' + slot.color + ';' +
        'text-align:' + (slot.alignment || 'right') + ';' +
        'font-family:\'Segoe UI\',Tahoma,Arial,sans-serif;">' +
        textContent + '</div>';
    });

    // ── Layer 4: Logo slots (coords × scale) ────────────────────
    (tpl.logoSlots || []).forEach(function(slot) {
      html += '<div class="des-layer-logo" style="' +
        'left:' + _s(slot.x,scale) + 'px;top:' + _s(slot.y,scale) + 'px;' +
        'width:' + _s(slot.width,scale) + 'px;height:' + _s(slot.height,scale) + 'px;">' +
        '<div class="des-logo-placeholder">' + (slot.key || 'شعار') + '</div></div>';
    });

    canvas.innerHTML = html;
  }

  function seedTestTemplate() {
    apiFetch('/api/designs/templates/seed-test', { method: 'POST' })
      .then(function(r) { return r.json(); })
      .then(function(d) {
        if (d.skipped) alert('قالب موجود مسبقاً — تم تحديث العرض.');
        loadTemplates();
      }).catch(function(e) { alert('خطأ: ' + e.message); });
  }

  // ── Editor ───────────────────────────────────────────────────────
  var _edTpl = null;
  var _edFonts = [];
  var _edLogos = [];
  var _edSelectedLogoIds = [];
  var _edZoom = 'fit'; // 'fit' | number (scale factor)
  var _edBgUrl = null;      // selected generated background object path
  var _edBgResults = [];    // last generation results [{url, source}]

  function edOpen(tplId) {
    var tpl = _templates.find(function(t) { return t.id === tplId; });
    if (!tpl) {
      // templates not loaded yet — fetch individually
      apiFetch('/api/designs/templates/' + tplId).then(function(r) { return r.json(); }).then(function(t) {
        _edTpl = t;
        _edBootstrap();
      });
    } else {
      _edTpl = tpl;
      _edBootstrap();
    }
  }

  function _edBootstrap() {
    _edSelectedLogoIds = [];
    _edZoom = 'fit';
    _edBgUrl = null;
    _edBgResults = [];
    switchTab('editor');
    var wrap   = document.getElementById('des-editor-wrap');
    var noTpl  = document.getElementById('des-editor-no-tpl');
    if (wrap) wrap.style.display = 'none';
    if (noTpl) noTpl.style.display = '';
    Promise.all([
      apiFetch('/api/designs/fonts').then(function(r) { return r.json(); }),
      apiFetch('/api/designs/logos').then(function(r) { return r.json(); }),
    ]).then(function(results) {
      _edFonts = results[0];
      _edLogos = results[1];
      _edBuildUI();
      if (noTpl) noTpl.style.display = 'none';
      if (wrap)  wrap.style.display  = '';
      edRenderCanvas();
    }).catch(function(e) { alert('خطأ في تحميل المحرّر: ' + e.message); });
  }

  function _edBuildUI() {
    var tpl = _edTpl;
    var titleSlot = (tpl.textSlots || []).find(function(s) { return s.key === 'title'; });
    var bodySlot  = (tpl.textSlots || []).find(function(s) { return s.key === 'body';  });

    // Sliders
    var tSz = titleSlot ? titleSlot.default_font_size : 72;
    var bSz = bodySlot  ? bodySlot.default_font_size  : 40;
    var tEl = document.getElementById('des-ed-title-sz');
    var bEl = document.getElementById('des-ed-body-sz');
    if (tEl) { tEl.min = Math.max(16, Math.round(tSz * 0.35)); tEl.max = Math.round(tSz * 1.6); tEl.value = tSz; }
    if (bEl) { bEl.min = Math.max(12, Math.round(bSz * 0.35)); bEl.max = Math.round(bSz * 1.6); bEl.value = bSz; }
    var tsv = document.getElementById('des-ed-title-sz-val');
    var bsv = document.getElementById('des-ed-body-sz-val');
    if (tsv) tsv.textContent = tSz;
    if (bsv) bsv.textContent = bSz;

    // Clear text fields
    var tTA = document.getElementById('des-ed-title');
    var bTA = document.getElementById('des-ed-body');
    var af  = document.getElementById('des-ed-autofit');
    if (tTA) tTA.value = '';
    if (bTA) bTA.value = '';
    if (af)  af.checked = false;

    // Font select + load fonts via FontFace API for instant application
    var sel = document.getElementById('des-ed-font');
    if (sel) {
      sel.innerHTML = '<option value="">الخط الافتراضي (النظام)</option>' +
        _edFonts.map(function(f) {
          return '<option value="' + f.fontName + '"' + (f.isDefault ? ' selected' : '') + '>' + f.fontName + '</option>';
        }).join('');
    }
    _edFonts.forEach(function(font) {
      var src = "url('/api/storage" + font.fontFileUrl + "')";
      // Inject @font-face for CSS fallback
      var styleId = 'face-' + font.id;
      if (!document.getElementById(styleId)) {
        var s = document.createElement('style');
        s.id = styleId;
        s.textContent = "@font-face{font-family:'" + font.fontName + "';src:" + src + ";}";
        document.head.appendChild(s);
      }
      // Also load via FontFace API so the font is immediately available
      if (typeof FontFace !== 'undefined' && !document.fonts.check('12px ' + font.fontName)) {
        var ff = new FontFace(font.fontName, src);
        ff.load().then(function(loaded) {
          document.fonts.add(loaded);
          edRenderCanvas(); // re-render once font is ready
        }).catch(function() {});
      }
    });

    // Logo library
    var logosEl    = document.getElementById('des-ed-logos');
    var logosEmpty = document.getElementById('des-ed-logos-empty');
    if (!_edLogos.length) {
      if (logosEl) logosEl.innerHTML = '';
      if (logosEmpty) logosEmpty.style.display = '';
    } else {
      if (logosEmpty) logosEmpty.style.display = 'none';
      if (logosEl) {
        logosEl.innerHTML = _edLogos.map(function(logo) {
          var checker = logo.transparent
            ? 'repeating-conic-gradient(#ddd 0% 25%,#fff 0% 50%) 0 0/12px 12px'
            : 'var(--surface-2)';
          return '<div class="des-ed-logo-thumb" id="des-ed-logo-' + logo.id + '" data-id="' + logo.id + '"' +
            ' onclick="DES.edToggleLogo(' + logo.id + ')" style="background:' + checker + ';">' +
            '<img src="/api/storage' + logo.fileUrl + '" alt="' + logo.logoName + '">' +
            '<div class="des-ed-logo-name">' + logo.logoName + '</div>' +
            '</div>';
        }).join('');
      }
    }
    _edUpdateCounters();
  }

  function _edUpdateCounters() {
    var tpl = _edTpl;
    if (!tpl) return;
    var titleSlot = (tpl.textSlots || []).find(function(s) { return s.key === 'title'; });
    var bodySlot  = (tpl.textSlots || []).find(function(s) { return s.key === 'body';  });

    var tTA = document.getElementById('des-ed-title');
    var bTA = document.getElementById('des-ed-body');
    var titleText = tTA ? tTA.value : '';
    var bodyText  = bTA ? bTA.value : '';

    function countWords(txt) { return txt.trim() ? txt.trim().split(/\s+/).length : 0; }

    var tw = countWords(titleText);
    var bw = countWords(bodyText);
    var tMax = titleSlot ? titleSlot.max_words : null;
    var bMax = bodySlot  ? bodySlot.max_words  : null;

    var tc = document.getElementById('des-ed-title-counter');
    var tw2= document.getElementById('des-ed-title-warn');
    if (tc) { tc.textContent = tMax ? tw + '/' + tMax + ' كلمة' : tw + ' كلمة'; tc.classList.toggle('over', !!tMax && tw > tMax); }
    if (tw2) { if (tMax && tw > tMax) { tw2.style.display = ''; tw2.textContent = '⚠ تجاوزت الحد المسموح (' + tMax + ' كلمة)'; } else { tw2.style.display = 'none'; } }

    var bc = document.getElementById('des-ed-body-counter');
    var bw2= document.getElementById('des-ed-body-warn');
    if (bc) { bc.textContent = bMax ? bw + '/' + bMax + ' كلمة' : bw + ' كلمة'; bc.classList.toggle('over', !!bMax && bw > bMax); }
    if (bw2) { if (bMax && bw > bMax) { bw2.style.display = ''; bw2.textContent = '⚠ تجاوزت الحد المسموح (' + bMax + ' كلمة)'; } else { bw2.style.display = 'none'; } }
  }

  function edUpdate() {
    var tSzEl = document.getElementById('des-ed-title-sz');
    var bSzEl = document.getElementById('des-ed-body-sz');
    var tsv   = document.getElementById('des-ed-title-sz-val');
    var bsv   = document.getElementById('des-ed-body-sz-val');
    if (tSzEl && tsv) tsv.textContent = tSzEl.value;
    if (bSzEl && bsv) bsv.textContent = bSzEl.value;
    _edUpdateCounters();
    edRenderCanvas();
  }

  function edToggleLogo(id) {
    var idx = _edSelectedLogoIds.indexOf(id);
    if (idx >= 0) { _edSelectedLogoIds.splice(idx, 1); } else { _edSelectedLogoIds.push(id); }
    _edLogos.forEach(function(logo) {
      var el = document.getElementById('des-ed-logo-' + logo.id);
      if (el) el.classList.toggle('selected', _edSelectedLogoIds.indexOf(logo.id) >= 0);
    });
    edRenderCanvas();
  }

  function _edAutoFit(text, slot, maxFontSize, fontStack) {
    if (!text || !slot) return maxFontSize;
    var m = document.getElementById('des-ed-measurer');
    if (!m) {
      m = document.createElement('div');
      m.id = 'des-ed-measurer';
      m.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;left:-9999px;top:0;direction:rtl;word-break:break-word;line-height:1.35;white-space:normal;overflow:visible;';
      document.body.appendChild(m);
    }
    m.style.width      = slot.width + 'px';
    m.style.fontFamily = fontStack || "Tahoma,'Segoe UI',Arial,sans-serif";
    var lo = 12, hi = maxFontSize, best = lo;
    while (lo <= hi) {
      var mid = Math.round((lo + hi) / 2);
      m.style.fontSize = mid + 'px';
      m.textContent    = text;
      if (m.scrollHeight <= slot.height) { best = mid; lo = mid + 1; } else { hi = mid - 1; }
    }
    return best;
  }

  function edZoom(action) {
    var outer = document.getElementById('des-ed-canvas-outer');
    if (!outer || !_edTpl) return;
    var W = _edTpl.canvasWidth || 1920;
    var fitScale = outer.clientWidth / W;
    var cur = (_edZoom === 'fit') ? fitScale : _edZoom;
    if (action === 'fit') {
      _edZoom = 'fit';
    } else if (action === '+') {
      _edZoom = Math.min(cur * 1.25, 4);
    } else if (action === '-') {
      var next = cur * 0.8;
      _edZoom = (next <= fitScale * 1.05) ? 'fit' : Math.max(next, 0.1);
    }
    edRenderCanvas();
  }

  function edRenderCanvas() {
    var tpl = _edTpl;
    if (!tpl) return;
    var outer  = document.getElementById('des-ed-canvas-outer');
    var canvas = document.getElementById('des-ed-canvas');
    if (!outer || !canvas) return;

    var W = tpl.canvasWidth  || 1920;
    var H = tpl.canvasHeight || 1080;
    var outerW = outer.clientWidth || outer.getBoundingClientRect().width;
    if (!outerW) { requestAnimationFrame(edRenderCanvas); return; }

    var fitScale = outerW / W;
    var scale    = (_edZoom === 'fit') ? fitScale : _edZoom;
    var sw = _s(W, scale);
    var sh = _s(H, scale);

    // Size canvas to scaled dimensions (no CSS transform used)
    canvas.style.width  = sw + 'px';
    canvas.style.height = sh + 'px';

    _sizeOuter(outer, sw, sh, _edZoom, document.getElementById('des-ed-zoom-pct'), scale);

    var titleText  = (document.getElementById('des-ed-title') || {}).value || '';
    var bodyText   = (document.getElementById('des-ed-body')  || {}).value || '';
    var autoFit    = !!(document.getElementById('des-ed-autofit') || {}).checked;
    var fontFamily = (document.getElementById('des-ed-font')  || {}).value || '';
    var titleSz    = parseInt((document.getElementById('des-ed-title-sz') || {}).value) || 72;
    var bodySz     = parseInt((document.getElementById('des-ed-body-sz')  || {}).value) || 40;
    var fontStack  = fontFamily ? "'" + fontFamily + "',Tahoma,Arial,sans-serif" : "Tahoma,'Segoe UI',Arial,sans-serif";

    var TEXT_MAP = { title: titleText, body: bodyText };
    var SIZE_MAP = { title: titleSz,   body: bodySz  };

    var html = '';

    // ── Layer 1: Background (generated image or placeholder) ────
    if (_edBgUrl) {
      html += '<div class="des-layer-bg">' +
        '<img src="/api/storage' + _edBgUrl + '" style="width:100%;height:100%;object-fit:cover;display:block;" alt="خلفية">' +
        '</div>';
    } else {
      html += '<div class="des-layer-bg" style="background:#6e7e8e;">' +
        '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;opacity:.15;">' +
        '<svg width="260" height="180" viewBox="0 0 260 180" fill="none"><rect width="260" height="180" fill="#444"/>' +
        '<circle cx="80" cy="72" r="28" fill="#666"/>' +
        '<path d="M0 148 L75 96 L130 126 L185 66 L260 148Z" fill="#555"/></svg>' +
        '</div></div>';
    }

    // ── Layer 2: Background panel (coords × scale) ──────────────
    var bp = tpl.backgroundPanelConfig;
    if (bp) {
      var rr = parseInt((bp.color || '#000').slice(1,3), 16) || 0;
      var gg = parseInt((bp.color || '#000').slice(3,5), 16) || 0;
      var bb = parseInt((bp.color || '#000').slice(5,7), 16) || 0;
      html += '<div class="des-layer-panel" style="' +
        'left:' + _s(bp.x,scale) + 'px;top:' + _s(bp.y,scale) + 'px;' +
        'width:' + _s(bp.width,scale) + 'px;height:' + _s(bp.height,scale) + 'px;' +
        'background:rgba(' + rr + ',' + gg + ',' + bb + ',' + bp.opacity + ');"></div>';
    }

    // ── Layer 3: Text slots (coords × scale, font-size × scale) ─
    // autoFit measures in original 1920-space, then we scale the result
    (tpl.textSlots || []).forEach(function(slot) {
      var text  = TEXT_MAP[slot.key] !== undefined ? TEXT_MAP[slot.key] : '';
      var fSize = SIZE_MAP[slot.key] || slot.default_font_size;
      var empty = !text.trim();
      if (autoFit && !empty) fSize = _edAutoFit(text, slot, fSize, fontStack);
      var content = empty
        ? '<span style="opacity:.25;">' + slot.label_ar + '</span>'
        : text.replace(/\n/g, '<br>');
      html += '<div class="des-layer-text" style="' +
        'left:' + _s(slot.x,scale) + 'px;top:' + _s(slot.y,scale) + 'px;' +
        'width:' + _s(slot.width,scale) + 'px;height:' + _s(slot.height,scale) + 'px;' +
        'font-size:' + _s(fSize,scale) + 'px;color:' + slot.color + ';' +
        'text-align:' + (slot.alignment || 'right') + ';' +
        'font-family:' + fontStack + ';">' + content + '</div>';
    });

    // ── Layer 4: Logo slots (coords × scale) ────────────────────
    (tpl.logoSlots || []).forEach(function(slot, idx) {
      var assignedId = _edSelectedLogoIds[idx] || null;
      var logo = assignedId ? _edLogos.find(function(l) { return l.id === assignedId; }) : null;
      var inner = logo
        ? '<img src="/api/storage' + logo.fileUrl + '" style="max-width:100%;max-height:100%;object-fit:contain;" alt="' + logo.logoName + '">'
        : '<div class="des-logo-placeholder">' + (slot.key || 'شعار') + '</div>';
      html += '<div class="des-layer-logo" style="' +
        'left:' + _s(slot.x,scale) + 'px;top:' + _s(slot.y,scale) + 'px;' +
        'width:' + _s(slot.width,scale) + 'px;height:' + _s(slot.height,scale) + 'px;">' +
        inner + '</div>';
    });

    canvas.innerHTML = html;
  }

  // ── AI Background Generation ─────────────────────────────────────
  var _edBgCooldownTimer = null; // 20-second cooldown between generation requests

  function edGenerateBg() {
    var promptEl  = document.getElementById('des-ed-bg-prompt');
    var spinnerEl = document.getElementById('des-ed-bg-spinner');
    var resultsEl = document.getElementById('des-ed-bg-results');
    var btnEl     = document.getElementById('des-ed-bg-btn');
    var btnLabel  = document.getElementById('des-ed-bg-btn-label');
    if (!promptEl || !_edTpl) return;
    var prompt = (promptEl.value || '').trim();
    if (!prompt) { alert('أدخل وصفاً للخلفية أولاً.'); promptEl.focus(); return; }

    // Show loading state
    if (spinnerEl) spinnerEl.style.display = '';
    if (resultsEl) { resultsEl.style.display = 'none'; resultsEl.innerHTML = ''; }
    if (btnLabel)  btnLabel.textContent = 'جاري التوليد…';

    // ── Cooldown helpers ─────────────────────────────────────────────
    var _cooldownInterval = null;
    function _startCooldown() {
      if (btnEl) btnEl.disabled = true;
      if (_edBgCooldownTimer) clearTimeout(_edBgCooldownTimer);
      var _cooldownSec = 20;
      _cooldownInterval = setInterval(function() {
        _cooldownSec--;
        if (btnLabel && btnEl && btnEl.disabled) btnLabel.textContent = 'انتظر ' + _cooldownSec + ' ث…';
        if (_cooldownSec <= 0) clearInterval(_cooldownInterval);
      }, 1000);
      _edBgCooldownTimer = setTimeout(function() {
        clearInterval(_cooldownInterval);
        if (btnEl) btnEl.disabled = false;
        if (btnLabel) btnLabel.textContent = '⬡ توليد ٤ خلفيات';
      }, 20000);
    }
    function _cancelCooldown() {
      if (_edBgCooldownTimer) { clearTimeout(_edBgCooldownTimer); _edBgCooldownTimer = null; }
      if (_cooldownInterval)  { clearInterval(_cooldownInterval);  _cooldownInterval  = null; }
      if (btnEl)    btnEl.disabled = false;
      if (btnLabel) btnLabel.textContent = '⬡ توليد ٤ خلفيات';
    }
    _startCooldown();
    // ─────────────────────────────────────────────────────────────────

    apiFetch('/api/designs/generate-backgrounds', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: prompt, templateId: _edTpl.id }),
    })
    .then(function(r) {
      if (!r.ok) return r.json().then(function(e) { throw new Error(e.error || r.status); });
      return r.json();
    })
    .then(function(data) {
      _edBgResults = data.images || [];
      if (spinnerEl) spinnerEl.style.display = 'none';
      if (!_edBgResults.length) { alert('لم يُرجع النموذج أي صور.'); return; }
      // Render thumbnails
      if (resultsEl) {
        resultsEl.innerHTML = _edBgResults.map(function(img, i) {
          return '<div class="des-bg-thumb" id="des-bg-thumb-' + i + '" onclick="DES.edSelectBg(' + i + ')">' +
            '<img src="/api/storage' + img.url + '" loading="lazy" alt="خلفية ' + (i+1) + '">' +
            '<div class="des-bg-num">' + (i+1) + '</div>' +
            '</div>';
        }).join('');
        resultsEl.style.display = '';
      }
      // Auto-select first
      edSelectBg(0);
    })
    .catch(function(err) {
      if (spinnerEl) spinnerEl.style.display = 'none';
      // On any error: cancel cooldown so user can retry immediately
      _cancelCooldown();
      var msg = err.message || '';
      if (!msg || msg === 'Failed to fetch' || msg === 'NetworkError when attempting to fetch resource.') {
        alert('تعذّر الوصول للخادم، تحقق من اتصالك وأعد المحاولة.');
      } else {
        alert(msg);
      }
    });
  }

  function edSelectBg(index) {
    var img = _edBgResults[index];
    if (!img) return;
    _edBgUrl = img.url;
    // Highlight selected thumb
    _edBgResults.forEach(function(_, i) {
      var el = document.getElementById('des-bg-thumb-' + i);
      if (el) el.classList.toggle('active', i === index);
    });
    edRenderCanvas();
  }

  function rerenderCanvases() {
    if (_tplCurrentTpl) renderCanvas(_tplCurrentTpl);
    if (_edTpl) edRenderCanvas();
  }

  return {
    init: init, switchTab: switchTab,
    uploadLogo: uploadLogo, deleteLogo: deleteLogo,
    uploadFont: uploadFont, setDefaultFont: setDefaultFont, deleteFont: deleteFont,
    selectTemplate: selectTemplate, seedTestTemplate: seedTestTemplate,
    edOpen: edOpen, edUpdate: edUpdate, edToggleLogo: edToggleLogo, edZoom: edZoom,
    edGenerateBg: edGenerateBg, edSelectBg: edSelectBg,
    tplZoom: tplZoom, rerenderCanvases: rerenderCanvases,
  };
})();

function designsInit() { DES.init(); }
function desSwitchTab(tab) { DES.switchTab(tab); }

// Re-render canvases on window resize (fixes fit-mode after resize)
(function() {
  var _resizeTimer;
  window.addEventListener('resize', function() {
    clearTimeout(_resizeTimer);
    _resizeTimer = setTimeout(function() {
      if (document.body.classList.contains('designs-mode')) {
        DES.rerenderCanvases();
      }
    }, 120);
  });
})();

// ── Report ───────────────────────────────────────────────────────
async function aiyGenerateReport() {
  try {
    var res = await apiFetch('/api/ai-year/report', { method: 'POST' });
    if (!res.ok) throw new Error('Server error ' + res.status);
    var blob = await res.blob();
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'AI-Year-2026-Report.docx';
    a.click();
    URL.revokeObjectURL(a.href);
  } catch(e) {
    alert('فشل توليد التقرير: ' + e.message);
  }
}

</script>
</body>
</html>
