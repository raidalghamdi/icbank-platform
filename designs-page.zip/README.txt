صفحة إنشاء التصاميم — بنك التواصل الداخلي
==========================================

الملفات:
--------
1. designs-section.html  — HTML كامل لقسم الصفحة (3 تبويبات: الأصول، القوالب، المحرّر)
2. designs.css           — كل CSS الخاص بالصفحة (classes تبدأ بـ .des-)
3. designs.js            — كائن DES الكامل بجميع الدوال (logo/font/template/editor/AI)
4. designs-route.ts      — مسارات API الخلفية (Express + Drizzle ORM + Gemini AI)

كيفية التكامل في الـ index.html:
---------------------------------
- ضع محتوى designs.css داخل وسم <style> في <head>
- ضع محتوى designs-section.html داخل <div class="main-inner"> كـ page-section
- ضع محتوى designs.js قبل </body> بعد دالة apiFetch()
- عند بدء الصفحة استدعِ: designsInit()
- عند الانتقال للصفحة: document.body.classList.add('designs-mode')

متغيرات بيئة مطلوبة:
----------------------
- GOOGLE_AI_API_KEY  — مفتاح Google Gemini API لتوليد الخلفيات

لتوليد 4 خلفيات بدلاً من 1 (وضع الإنتاج):
-------------------------------------------
في designs-route.ts سطر 198:
  const GEN_COUNT = 1;  // ← غيّر إلى 4

نموذج Gemini المستخدم: gemini-2.5-flash-image (Nano Banana)
